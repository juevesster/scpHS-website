# SCPHS Website (Local Dev)

## Quick start
1. Open this folder in VS Code.
2. Install the "Live Server" extension (if not yet installed).
3. Right‑click `index.html` → **Open with Live Server** (http://localhost:....).

## Endpoint
Your Apps Script Web App endpoint is set in `assets/js/config.js`:

https://script.google.com/macros/s/AKfycbzpOyMomau55oJSJp2-NM3cOBkjIBihxGAq95ZSDiQ9Xd7Yrcvp2Vurhme3NzvlQvCEvw/exec

Make sure your deployment access is **Anyone with the link**.

## Pages
- `index.html`: Home with center feed (chips, load more, auto‑refresh).
- `issuances.html`: Archive with search, filters, pagination.

## Defaults
- Home defaults to **SDO Nueva Vizcaya** (division). Change in `assets/js/index.js`:
  `let currentLevel = 'division';` → `''` for All, `'national'` for DepEd only.

## Troubleshooting
- If the center feed says "Failed to load issuances":
  - Open DevTools → **Console**: check any error (HTTP status, missing variable).
  - Test endpoint directly: add `?limit=5` or `?level=division`.
  - Ensure Live Server is used instead of `file:///`.
